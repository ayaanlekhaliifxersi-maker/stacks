ALL STACKS CHAPTER CODES IN ONE FILE

Main file: AllStacksChapter.java

Compile:
    javac AllStacksChapter.java

Run:
    java AllStacksChapter

The program runs these examples in sequence:
1. Built-in Java Stack (push, pop, peek, size, isEmpty)
2. Generics (Box<Integer> and Box<String>)
3. Undo last bank deposit
4. Undo last course registration
5. Reverse a String using Stack
6. ArrayStack with automatic capacity expansion
7. Stack underflow handling
8. Node structure
9. LinkedStack (push, pop, peek, size, isEmpty)
10. Linked-list traversal, insertion at head, deletion at head

All helper classes are nested inside the public AllStacksChapter class,
so the entire chapter example set can be compiled from this one Java file.
